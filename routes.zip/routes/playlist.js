const express = require('express');
const Playlist = require('../models/Playlist');
const router = express.Router();
const mongoose = require('mongoose');
const Song = require('../models/Song');

// Create a new playlist
router.post('/create', async (req, res) => {
    try {
        const { name} = req.body;

        const playlist = new Playlist({
            name,
            createdBy: 'default-system',
            songs: []
        });

        await playlist.save();
        console.log('Created Playlist:', playlist);
        res.json({ success: true, playlistId: playlist._id });
    } catch (err) {
        console.error('Error creating playlist:', err);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

// Render new playlist creation page
router.get('/create', (req, res) => {
    res.render('create-playlist', { playlist: { name: '', songs: [] } });
});

// API to fetch playlist data
router.get('/:id/json', async (req, res) => {
    try {
        const playlist = await Playlist.findById(req.params.id).populate('songs');
        if (!playlist) {
            return res.status(404).json({ error: 'Playlist not found' });
        }
        res.json(playlist);
    } catch (err) {
        console.error('Error fetching playlist:', err);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});




// Add a song to a playlist
router.post('/:playlistId/add-song', async (req, res) => {
    try {
        const { playlistId } = req.params;
        const { songId } = req.body;

        console.log('Adding song to playlist:', { playlistId, songId }); // Debugging

        const playlist = await Playlist.findById(playlistId);
        if (!playlist) {
            console.error('Playlist not found:', playlistId);
            return res.status(404).json({ error: 'Playlist not found' });
        }

        if (!playlist.songs.includes(songId)) {
            playlist.songs.push(songId);
            await playlist.save();
        }
        console.log('Playlist data passed to EJS:', playlist);
        res.json({ success: true, playlist });
    } catch (err) {
        console.error('Error adding song to playlist:', err);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});





module.exports = router;

