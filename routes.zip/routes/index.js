const express = require('express');
const router = express.Router();
const Playlist = require('../models/Playlist'); // Import the Playlist model

// Route to render index2.ejs
router.get('/index2', async (req, res) => {
    try {
        const playlists = await Playlist.find(); // Fetch all playlists
        res.render('index2', { playlists }); // Pass playlists to the template
    } catch (err) {
        console.error('Error fetching playlists:', err);
        res.status(500).send('Internal Server Error');
    }
});

module.exports = router;
