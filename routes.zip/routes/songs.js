const express = require('express');
const Song = require('../models/Song');
const Playlist = require('../models/Playlist');
const router = express.Router();


router.get('/', async (req, res) => {
    try {
        const { title, artist, genre } = req.query;

        console.log('Request Query Parameters:', req.query); // Log query parameters

        const query = {};
        if (title) query.title = { $regex: title, $options: 'i' }; // Case-insensitive regex
        if (artist) query.artist = { $regex: artist, $options: 'i' };
        if (genre) query.genre = { $regex: genre, $options: 'i' };

        const songs = await Song.find(query);
        console.log('Songs Found:', songs); // Log the songs found

        // Ensure a playlist exists
        let playlist = await Playlist.findOne({ name: 'Default Playlist'  }); 
        if (!playlist) {
            playlist = await Playlist.create({
                name: 'Default Playlist',
                createdBy: 'default-system', 
                songs: []
            });
            console.log('New Playlist Created:', playlist); // Debugging
        }

        console.log('Playlist Object:', playlist); // Ensure playlist is valid
        console.log('Playlist ID:', playlist._id); // Ensure _id is not undefined

        // Respond based on request type
        if (req.xhr || req.headers.accept.includes('json')) {
            console.log('Returning JSON Response');
            return res.json(songs); // Send JSON for AJAX
        } else {
            console.log('Rendering EJS Template');
            return  res.render('song-search', { songs, playlistId: playlist._id }); // Pass playlistId to EJS
        }
    } catch (err) {
        console.error('Error in /songs route:', err);
        res.status(500).send('Internal Server Error');
    }
});



// Add Song to Playlist
router.post('/add-to-playlist', async (req, res) => {
    try {
        const { playlistId, songId } = req.body;

        const playlist = await Playlist.findById(playlistId);
        const song = await Song.findById(songId);

        if (!playlist) {
            return res.status(404).json({ error: 'Playlist not found' });
        }
        if (!song) {
            return res.status(404).json({ error: 'Song not found' });
        }

        // Check if the song is already in the playlist
        if (!playlist.songs.includes(songId)) {
            playlist.songs.push(songId);
            await playlist.save();
            console.log(`Song ${songId} added to Playlist ${playlistId}`);
        } else {
            console.log(`Song ${songId} is already in Playlist ${playlistId}`);
        }

        res.json({ success: true, playlist }); // Respond with the updated playlist
    } catch (err) {
        console.error('Error adding song to playlist:', err);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

module.exports = router;
