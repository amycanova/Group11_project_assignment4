const mongoose = require('mongoose');

const PlaylistSchema = new mongoose.Schema({
    name: { type: String, required: true },
    createdBy: { type: String, required: true },
    songs: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Song' }],
});

// Ensure _id is automatically added by MongoDB
module.exports = mongoose.model('Playlist', PlaylistSchema);
