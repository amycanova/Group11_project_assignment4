// Function to add a new item (event or promotion)
function addNewItem(sectionClass) {
    const container = document.querySelector(`.${sectionClass}`);
    
    // Create a single new item to add
    const newItem = document.createElement('div');
    newItem.classList.add(sectionClass === 'news-container' ? 'news-card' : 'promotion-card');
    newItem.innerHTML = `
        <p class="${sectionClass === 'news-container' ? 'news-title' : 'promotion-title'}" contenteditable="true">New ${sectionClass === 'news-container' ? 'Event' : 'Promotion'} Title</p>
        <textarea placeholder="Details go here..." contenteditable="true"></textarea>
        <button onclick="deleteItem(this)">Delete</button>
    `;

    // Append the single new item to the specified container
    container.appendChild(newItem);
}

// Function to delete an item
function deleteItem(button) {
    const itemCard = button.parentElement;
    itemCard.remove();
}

// Handle add new event or promotion
function handleAddNewClick(event) {
    if (event.target.matches('.new-btn')) {
        const sectionClass = event.target.closest('section').classList.contains('news-section') 
            ? 'news-container' 
            : 'promotions-container';
        
        addNewItem(sectionClass);
    }
}

document.addEventListener("DOMContentLoaded", () => {
    console.log("DOM fully loaded"); // Confirms the DOM is ready

    // Handle title editing for both news and promotions
    const editableTitles = document.querySelectorAll(".news-title, .promotion-title");

    editableTitles.forEach((title) => {
        title.addEventListener("click", () => {
            if (title.tagName === "P") {
                const input = document.createElement("input");
                input.type = "text";
                input.classList.add(title.classList.contains("news-title") ? "news-title" : "promotion-title");
                input.value = title.textContent;

                title.replaceWith(input);
                input.focus();

                input.addEventListener("blur", () => {
                    const newTitle = document.createElement("p");
                    newTitle.classList.add(input.classList.contains("news-title") ? "news-title" : "promotion-title");
                    newTitle.textContent = input.value;

                    input.replaceWith(newTitle);

                    // Reattach click event to make it editable again
                    newTitle.addEventListener("click", () => {
                        input.replaceWith(newTitle);
                    });
                });
            }
        });
    });
});
