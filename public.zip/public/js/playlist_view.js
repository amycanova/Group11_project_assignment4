function addSongToList(title, artist) {
    const songList = document.getElementById('song-list');
    const li = document.createElement('li');
    li.innerHTML = `
        <span>${title} - ${artist}</span>
        <button class="delete-btn" onclick="deleteSong(this)">Delete</button>
    `;
    songList.appendChild(li);
}

function deleteSong(button) {
    const song = button.parentElement;
    song.remove();
}

document.getElementById('refresh-playlist').addEventListener('click', loadPlaylist);

function loadPlaylist() {
    // Fetch the playlist ID from the hidden input field
    const playlistId = document.getElementById('playlist-id').value;

    fetch(`/playlist/${playlistId}/json`)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then(playlist => {
            const songList = document.getElementById('song-list');
            songList.innerHTML = ''; // Clear the current list

            if (playlist.songs.length === 0) {
                const noSongsItem = document.createElement('li');
                noSongsItem.textContent = 'No songs in this playlist.';
                songList.appendChild(noSongsItem);
            } else {
                playlist.songs.forEach(song => {
                    const li = document.createElement('li');
                    li.textContent = `${song.title} - ${song.artist}`;
                    songList.appendChild(li);
                });
            }
        })
        .catch(err => {
            console.error('Error loading playlist:', err);
            alert('Failed to load playlist. Please try again.');
        });
}
