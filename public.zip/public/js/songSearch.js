function searchSongs() {
    const title = document.getElementById('title').value.trim();
    const artist = document.getElementById('artist').value.trim();
    const genre = document.getElementById('genre').value.trim();

    // Retrieve the playlist ID (assume it's stored in a hidden input field or globally)
    const playlistId = document.getElementById('playlistId')?.value;

    if (!playlistId) {
        console.error('Playlist ID is missing!');
        alert('Unable to fetch songs because Playlist ID is missing.');
        return;
    }

    if (!title && !artist && !genre) {
        alert('Please enter at least one search criterion.');
        return;
    }

    // Build the search URL, including the playlistId
    const url = `/songs?title=${encodeURIComponent(title)}&artist=${encodeURIComponent(artist)}&genre=${encodeURIComponent(genre)}&playlistId=${encodeURIComponent(playlistId)}`;
    console.log('Fetching URL:', url); // Log the URL

    fetch(url, {
        method: 'GET',
        headers: {
            'Accept': 'application/json' // Tell the server we expect JSON
        }
    })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json(); // Parse JSON
        })
        .then(songs => {
            console.log('Fetched Songs:', songs); // Log fetched songs
            updateResultsTable(songs, playlistId); // Pass the playlistId to updateResultsTable
        })
        .catch(err => {
            console.error('Error fetching songs:', err); // Log errors
            alert('An error occurred while fetching songs.');
        });
}



function displayResults(songs) {
    const resultsTableBody = document.getElementById('results');
    resultsTableBody.innerHTML = ''; // Clear previous results

    if (songs.length === 0) {
        const row = document.createElement('tr');
        row.innerHTML = '<td colspan="4">No results found.</td>';
        resultsTableBody.appendChild(row);
    } else {
        songs.forEach(song => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${song.title}</td>
                <td>${song.artist}</td>
                <td>${song.genre}</td>
                <td><button onclick="addToPlaylist('${song._id}')">Add</button></td>
            `;
            resultsTableBody.appendChild(row);
        });
    }
}

function addToPlaylist(songId, playlistId) {
    console.log('addToPlaylist called with:', { songId, playlistId }); // Log inputs for debugging

    if (!playlistId) {
        console.error('Playlist ID is undefined!');
        alert('Unable to add song to playlist. Playlist ID is missing.');
        return;
    }
    console.log('Adding song:', { songId, playlistId });
    fetch(`/playlist/${playlistId}/add-song`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ songId }), // Ensure songId is correctly serialized
    })
        .then(response => {
            if (!response.ok) {
                return response.json().then(error => {
                    throw new Error(error.error || 'Failed to add song');
                });
            }
            return response.json();
        })
        .then(data => {
            console.log('Song added to playlist:', data);
            alert('Song successfully added to playlist!');
        })
        .catch(err => {
            console.error('Error adding song:', err.message);
            alert(`Failed to add song: ${err.message}`);
        });
}



function updateResultsTable(songs) {
    const resultsContainer = document.getElementById('results'); // Target the table body
    const playlistId = document.getElementById('playlistId').value; // Get the playlist ID

    resultsContainer.innerHTML = ''; // Clear previous results

    if (songs.length === 0) {
        const row = document.createElement('tr');
        const noResultsCell = document.createElement('td');
        noResultsCell.colSpan = 4; // Span across all columns
        noResultsCell.textContent = 'No results found.';
        row.appendChild(noResultsCell);
        resultsContainer.appendChild(row);
        return;
    }

    songs.forEach(song => {
        const row = document.createElement('tr');

        const titleCell = document.createElement('td');
        titleCell.textContent = song.title;

        const artistCell = document.createElement('td');
        artistCell.textContent = song.artist;

        const genreCell = document.createElement('td');
        genreCell.textContent = song.genre || 'Unknown Genre';

        const actionCell = document.createElement('td');
        const addButton = document.createElement('button');
        addButton.textContent = 'Add to Playlist';

        addButton.onclick = () => addToPlaylist(song._id, playlistId);

        actionCell.appendChild(addButton);

        row.appendChild(titleCell);
        row.appendChild(artistCell);
        row.appendChild(genreCell);
        row.appendChild(actionCell);

        resultsContainer.appendChild(row);
    });
}
