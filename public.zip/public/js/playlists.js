// Define the Playlist class to manage individual playlists
class Playlist {
    constructor(name) {
        this.name = name;
    }

    // Method to create the HTML structure for a playlist card
    render() {
        const newCard = document.createElement("div");
        newCard.classList.add("playlist-card");

        // Inner HTML structure with image, title input, and delete button
        newCard.innerHTML = `
            <a href="create-playlist.html">
                <img src="default-image.jpg" alt="New Playlist Image">
            </a>
            <input type="text" class="playlist-title" value="${this.name}" />
            <button class="delete-btn">Delete</button>
        `;

        return newCard;
    }
}

// Function to handle adding a new playlist card to the container
function addNewPlaylist() {
    const playlistContainer = document.querySelector(".playlist-container");

    // Create a new playlist instance with default name
    const newPlaylist = new Playlist("New Playlist");
    const newCard = newPlaylist.render();

    // Append the new playlist card to the container
    playlistContainer.appendChild(newCard);

    // Add delete functionality to the delete button within the new card
    const deleteBtn = newCard.querySelector(".delete-btn");
    deleteBtn.addEventListener("click", () => {
        if (window.confirm("Are you sure you want to delete this playlist?")) {
            newCard.remove(); // Remove the card from the DOM
        }
    });

    // Add an event listener to the title input to detect name changes
    const titleInput = newCard.querySelector(".playlist-title");
    titleInput.addEventListener("input", (event) => {
        console.log("Playlist name changed to:", event.target.value);
    });
}

// DOMContentLoaded event to ensure the DOM is ready before adding listeners
document.addEventListener("DOMContentLoaded", () => {
    console.log("DOM fully loaded");

    // Attach click event to the 'Create New Playlist' button
    const createPlaylistBtn = document.querySelector(".createPlaylist-btn");
    createPlaylistBtn.addEventListener("click", addNewPlaylist);
});
