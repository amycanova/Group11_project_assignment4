function validateForm() {
    const requiredFields = document.querySelectorAll('input[required]');
    for (const field of requiredFields) {
        if (!field.value.trim()) {
            alert(`Please fill out the ${field.name} field.`);
            return false;
        }
    }
    return true;
}
