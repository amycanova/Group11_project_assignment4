function addNewItem(sectionClass) {
    const container = document.querySelector(`.${sectionClass}`);
    const newItem = document.createElement('div');
    newItem.classList.add('item-card');
    newItem.innerHTML = `
        <input type="text" placeholder="Title">
        <textarea placeholder="Details"></textarea>
        <button onclick="deleteItem(this)">Delete</button>
    `;
    container.appendChild(newItem);
}

function deleteItem(button) {
    button.parentElement.remove();
}
